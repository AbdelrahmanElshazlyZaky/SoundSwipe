﻿/*
	TUIO C# Demo - part of the reacTIVision project
	Copyright (c) 2005-2016 Martin Kaltenbrunner <martin@tuio.org>

	This program is free software; you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation; either version 2 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program; if not, write to the Free Software
	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/


/////Notes for running code/////
///TUIO from 0-6 -> musical notes (DO,RE,MI...)
///TUIO form 9-11 -> login accounts
///TUIO 8 -> to logout of account
///If you try to scan a musical note TUIO (from 0-6) it will not work unless you login
///If you try to scan another account while you are already logged in it will not allow
///You can play the musical notes in the order you want over and over
///


using System;
using System.Drawing;
using System.Windows.Forms;
using System.ComponentModel;
using System.Collections.Generic;
using System.Collections;
using System.Threading;
using TUIO;
using System.Drawing.Drawing2D;
using System.IO;
using System.Media;
using NAudio.Wave;
using System.Threading.Tasks;
using System;
using System.Drawing;
using System.Windows.Forms;
using System.ComponentModel;
using System.Collections.Generic;
using System.IO;
using System.Media;
using System.Runtime.InteropServices;
using TUIO;
using NAudio.CoreAudioApi;

public class TuioDemo : Form, TuioListener
{
    private TuioClient client;
    private Dictionary<long, TuioObject> objectList;
    private Dictionary<long, TuioCursor> cursorList;
    private Dictionary<long, TuioBlob> blobList;

    private SoundPlayer player;
    private IAudioEndpointVolume volume;

    public static int width, height;
    private int window_width = 640;
    private int window_height = 480;
    private int window_left = 0;
    private int window_top = 0;
    private int screen_width = Screen.PrimaryScreen.Bounds.Width;
    private int screen_height = Screen.PrimaryScreen.Bounds.Height;

    private bool fullscreen;
    private bool verbose;

    Font font = new Font("Arial", 10.0f);
    SolidBrush fntBrush = new SolidBrush(Color.White);
    SolidBrush bgrBrush = new SolidBrush(Color.FromArgb(0, 0, 64));
    SolidBrush curBrush = new SolidBrush(Color.FromArgb(192, 0, 192));
    SolidBrush objBrush = new SolidBrush(Color.FromArgb(64, 0, 0));
    SolidBrush blbBrush = new SolidBrush(Color.FromArgb(64, 64, 64));
    Pen curPen = new Pen(new SolidBrush(Color.Blue), 1);
    public int SessionID = 0;
    public int countangel = 0;
    int Flag = 0;

    private Image landscapeImage; /// Background Image
    private string welcomeMessage;

    private string doMessage = string.Empty; // Message for DO note
    private bool isPlayingDo = false; // Flag to check if DO is active

    private Image musicalNoteImage; ///Musical note image
    private Image musicalNote;


    private string ReMessage = string.Empty; // Message for RE note
    private bool isPlayingRe = false; // Flag to check if RE is active

    private string MiMessage = string.Empty; // Message for MI note
    private bool isPlayingMi = false; // Flag to check if MI is active

    private string FaMessage = string.Empty; // Message for FA note
    private bool isPlayingFa = false; // Flag to check if FA is active

    private string SoMessage = string.Empty; // Message for SOL note
    private bool isPlayingSo = false; // Flag to check if SOL is active

    private string LaMessage = string.Empty; // Message for LA note
    private bool isPlayingLa = false; // Flag to check if LA is active

    private string SiMessage = string.Empty; // Message for SI note
    private bool isPlayingSi = false; // Flag to check if SI is active

    public TuioDemo(int port)
    {
        landscapeImage = Image.FromFile("BG2.JPG"); //Background image
        welcomeMessage = string.Empty; // Initialize the message

        musicalNoteImage = Image.FromFile("I.WEBP"); //Treble clef
        musicalNoteImage = RemoveBackground(musicalNoteImage, Color.White);
        musicalNoteImage = ResizeImage(musicalNoteImage, 400, 330);

        musicalNote = Image.FromFile("NNNNN.PNG"); //Musical note
        musicalNote = RemoveBackground(musicalNote, Color.White);
        musicalNote = ResizeImage(musicalNote, 55, 100);

        verbose = false;
        fullscreen = false;
        width = window_width;
        height = window_height;

        this.ClientSize = new System.Drawing.Size(width, height);
        this.Name = "TuioDemo";
        this.Text = "TuioDemo";

        this.Closing += new CancelEventHandler(Form_Closing);
        this.KeyDown += new KeyEventHandler(Form_KeyDown);

        this.SetStyle(ControlStyles.AllPaintingInWmPaint |
                        ControlStyles.UserPaint |
                        ControlStyles.DoubleBuffer, true);

        objectList = new Dictionary<long, TuioObject>(128);
        cursorList = new Dictionary<long, TuioCursor>(128);
        blobList = new Dictionary<long, TuioBlob>(128);

        client = new TuioClient(port);
        client.addTuioListener(this);

        client.connect();
        InitializeVolumeControl();
    }



    private void InitializeVolumeControl()//here 
    {
        // Instantiate the device enumerator
        var deviceEnumerator = (IMMDeviceEnumerator)new MMDeviceEnumerator();
        // Get the default audio endpoint (speakers)
        IMMDevice speakers;
        deviceEnumerator.GetDefaultAudioEndpoint(EDataFlow.eRender, ERole.eMultimedia, out speakers);

        // Activate the IAudioEndpointVolume interface on the default device
        Guid IID_IAudioEndpointVolume = typeof(IAudioEndpointVolume).GUID;
        object o;
        speakers.Activate(ref IID_IAudioEndpointVolume, 0, IntPtr.Zero, out o);
        volume = (IAudioEndpointVolume)o;

    }
    private Image ResizeImage(Image img, int width, int height)
    {
        Bitmap resizedImage = new Bitmap(width, height);
        using (Graphics g = Graphics.FromImage(resizedImage))
        {
            g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
            g.DrawImage(img, 0, 0, width, height);
        }
        return resizedImage;
    }
    private Image RemoveBackground(Image img, Color backgroundColor)
    {
        Bitmap bitmap = new Bitmap(img);
        for (int y = 0; y < bitmap.Height; y++)
        {
            for (int x = 0; x < bitmap.Width; x++)
            {
                Color pixelColor = bitmap.GetPixel(x, y);
                if (pixelColor.ToArgb() == backgroundColor.ToArgb())
                {
                    bitmap.SetPixel(x, y, Color.Transparent);
                }
            }
        }
        return bitmap;
    }

    protected override void OnPaint(PaintEventArgs e)
    {
        if (landscapeImage != null)
        {
            e.Graphics.DrawImage(landscapeImage, 0, 0, this.ClientSize.Width, this.ClientSize.Height);
        }
        if (Flag == 0)
        {
            Font loginFont = new Font("Arial", 20, FontStyle.Bold);
            SolidBrush loginBrush = new SolidBrush(Color.Black); 
            PointF loginTextPosition = new PointF(20, 20);
            e.Graphics.DrawString("Please scan your TUIO to login", loginFont, loginBrush, loginTextPosition);
        }
        if (musicalNoteImage != null && Flag == 1)
        {
            PointF notePosition = new PointF(200, 50);
            e.Graphics.DrawImage(musicalNoteImage, notePosition);
        }
        if (!string.IsNullOrEmpty(welcomeMessage))
        {
            Font customFont = new Font("Arial", 25, FontStyle.Bold);
            SolidBrush customBrush = new SolidBrush(Color.Black);
            PointF textPosition = new PointF(20, 20); // Change coordinates as needed
            e.Graphics.DrawString(welcomeMessage, customFont, customBrush, textPosition);
        }
        if (isPlayingDo)
        {
            Font doFont = new Font("Arial", 20, FontStyle.Bold);
            SolidBrush doBrush = new SolidBrush(Color.Black);
            PointF doTextPosition = new PointF(250, 350); 
            e.Graphics.DrawString(doMessage, doFont, doBrush, doTextPosition);
            PointF notePosition = new PointF(320, 206); 
            e.Graphics.DrawImage(musicalNote, notePosition);
        }
        else if (isPlayingRe)
        {
            Font ReFont = new Font("Arial", 20, FontStyle.Bold);
            SolidBrush ReBrush = new SolidBrush(Color.Black);
            PointF ReTextPosition = new PointF(250, 350); 
            e.Graphics.DrawString(ReMessage, ReFont, ReBrush, ReTextPosition);
            PointF notePosition = new PointF(350, 180); 
            e.Graphics.DrawImage(musicalNote, notePosition);
        }
        else if (isPlayingMi)
        {
            Font MiFont = new Font("Arial", 20, FontStyle.Bold);
            SolidBrush MiBrush = new SolidBrush(Color.Black);
            PointF MiTextPosition = new PointF(250, 350); 
            e.Graphics.DrawString(MiMessage, MiFont, MiBrush, MiTextPosition);
            PointF notePosition = new PointF(380, 172); 
            e.Graphics.DrawImage(musicalNote, notePosition);
        }
        else if (isPlayingFa)
        {
            Font FaFont = new Font("Arial", 20, FontStyle.Bold);
            SolidBrush FaBrush = new SolidBrush(Color.Black);
            PointF FaTextPosition = new PointF(250, 350); 
            e.Graphics.DrawString(FaMessage, FaFont, FaBrush, FaTextPosition);
            PointF notePosition = new PointF(410, 152); 
            e.Graphics.DrawImage(musicalNote, notePosition);
        }
        else if (isPlayingSo)
        {
            Font SoFont = new Font("Arial", 20, FontStyle.Bold);
            SolidBrush SoBrush = new SolidBrush(Color.Black);
            PointF SoTextPosition = new PointF(250, 350);
            e.Graphics.DrawString(SoMessage, SoFont, SoBrush, SoTextPosition);
            PointF notePosition = new PointF(440, 140); 
            e.Graphics.DrawImage(musicalNote, notePosition);
        }
        else if (isPlayingLa)
        {
            Font LaFont = new Font("Arial", 20, FontStyle.Bold);
            SolidBrush LaBrush = new SolidBrush(Color.Black);
            PointF LaTextPosition = new PointF(250, 350); 
            e.Graphics.DrawString(LaMessage, LaFont, LaBrush, LaTextPosition);
            PointF notePosition = new PointF(470, 125); 
            e.Graphics.DrawImage(musicalNote, notePosition);
        }
        else if (isPlayingSi)
        {
            Font SiFont = new Font("Arial", 20, FontStyle.Bold);
            SolidBrush SiBrush = new SolidBrush(Color.Black);
            PointF SiTextPosition = new PointF(250, 350); 
            e.Graphics.DrawString(SiMessage, SiFont, SiBrush, SiTextPosition);
            PointF notePosition = new PointF(500, 115); 
            e.Graphics.DrawImage(musicalNote, notePosition);
        }
        base.OnPaint(e);
    }
    private void Form_KeyDown(object sender, System.Windows.Forms.KeyEventArgs e)
    {
        if (e.KeyData == Keys.F1)
        {
            if (fullscreen == false)
            {
                width = screen_width;
                height = screen_height;

                window_left = this.Left;
                window_top = this.Top;

                this.FormBorderStyle = FormBorderStyle.None;
                this.Left = 0;
                this.Top = 0;
                this.Width = screen_width;
                this.Height = screen_height;

                fullscreen = true;
            }
            else
            {
                width = window_width;
                height = window_height;

                this.FormBorderStyle = FormBorderStyle.Sizable;
                this.Left = window_left;
                this.Top = window_top;
                this.Width = window_width;
                this.Height = window_height;

                fullscreen = false;
            }
        }
        else if (e.KeyData == Keys.Escape)
        {
            this.Close();
        }
        else if (e.KeyData == Keys.V)
        {
            verbose = !verbose;
        }
    }

    private void Form_Closing(object sender, System.ComponentModel.CancelEventArgs e)
    {
        client.removeTuioListener(this);
        client.disconnect();

        System.Environment.Exit(0);
    }

    public void addTuioObject(TuioObject o)
    {
        lock (objectList) 
        {
            objectList.Add(o.SessionID, o);
            // Number of markers is seen in the camera at a moment
            System.Diagnostics.Debug.WriteLine("obj list " + objectList.Count);
        }

        // Check for the specific marker ID
        if (o.SymbolID == 0 && Flag==0)
        {
            welcomeMessage = "Welcome Reem"; 
            Flag = 1;
        }
        else if(o.SymbolID==10 && Flag==0)
        {
            welcomeMessage = "Welcome Shahd"; 
            Flag = 1;
        }
        else if (o.SymbolID == 11 && Flag==0)
        {
            welcomeMessage = "Welcome Mariam"; 
            Flag = 1;
        }
        else if(o.SymbolID == 8)
        {
            welcomeMessage = string.Empty; 
            Flag = 0;
            doMessage = string.Empty; 
            isPlayingDo = false; 
            ReMessage = string.Empty; 
            isPlayingRe = false;
            MiMessage = string.Empty; 
            isPlayingMi = false;
            FaMessage = string.Empty; 
            isPlayingFa = false;
            SoMessage = string.Empty; 
            isPlayingSo = false;
            LaMessage = string.Empty; 
            isPlayingLa = false;
            SiMessage = string.Empty; 
            isPlayingSi = false;
            StopSound();
        }
        else if (o.SymbolID == 0 && Flag == 1) 
        {
            doMessage = "You are now playing DO"; 
            isPlayingDo = true; 
        }
        else if (o.SymbolID == 1 && Flag == 1) 
        {
            ReMessage = "You are now playing RE"; 
            isPlayingRe = true; 
            doMessage = string.Empty;
            isPlayingDo = false;
        }
        else if (o.SymbolID == 2 && Flag == 1) 
        {
            MiMessage = "You are now playing MI"; 
            isPlayingMi = true; 
            doMessage = string.Empty; 
            isPlayingDo = false;
            ReMessage = string.Empty; 
            isPlayingRe = false;
        }
        else if (o.SymbolID == 3 && Flag == 1) 
        {
            FaMessage = "You are now playing FA"; 
            isPlayingFa = true; 
            doMessage = string.Empty; 
            isPlayingDo = false;
            ReMessage = string.Empty; 
            isPlayingRe = false;
            MiMessage = string.Empty; 
            isPlayingMi = false;
        }
        else if (o.SymbolID == 4 && Flag == 1) 
        {
            SoMessage = "You are now playing SOL"; 
            isPlayingSo = true;
            doMessage = string.Empty; 
            isPlayingDo = false;
            ReMessage = string.Empty; 
            isPlayingRe = false;
            MiMessage = string.Empty; 
            isPlayingMi = false;
            FaMessage = string.Empty; 
            isPlayingFa = false;
        }
        else if (o.SymbolID == 5 && Flag == 1) 
        {
            LaMessage = "You are now playing LA"; 
            isPlayingLa = true; 
            doMessage = string.Empty; 
            isPlayingDo = false;
            ReMessage = string.Empty; 
            isPlayingRe = false;
            MiMessage = string.Empty; 
            isPlayingMi = false;
            FaMessage = string.Empty; 
            isPlayingFa = false;
            SoMessage = string.Empty; 
            isPlayingSo = false;
        }
        else if (o.SymbolID == 6 && Flag == 1) 
        {
            SiMessage = "You are now playing Si"; 
            isPlayingSi = true; 
            doMessage = string.Empty; 
            isPlayingDo = false;
            ReMessage = string.Empty; 
            isPlayingRe = false;
            MiMessage = string.Empty; 
            isPlayingMi = false;
            FaMessage = string.Empty; 
            isPlayingFa = false;
            SoMessage = string.Empty; 
            isPlayingSo = false;
            LaMessage = string.Empty; 
            isPlayingLa = false;
        }
        Invalidate(); // Trigger a repaint to update the UI
        if (verbose) Console.WriteLine("add obj " + o.SymbolID + " (" + o.SessionID + ") " + o.X + " " + o.Y + " " + o.Angle);
        if(Flag==1)
        {
            PlaySoundForSymbol(o.SymbolID);
        }
    }

    public void updateTuioObject(TuioObject o)
    {
        countangel++;
        if (countangel % 10 == 0)
        {
            if (verbose) Console.WriteLine("set obj " + o.SymbolID + " " + o.SessionID + " " + o.X + " " + o.Y + " " + o.Angle + " " + o.MotionSpeed + " " + o.RotationSpeed + " " + o.MotionAccel + " " + o.RotationAccel);


        }
        if (SessionID == 5) // Check for the specific TUIO object (ID 5)
        {

            SetVolumeFromAngle(o.Angle);
        }
    }
    private void SetVolumeFromAngle(float angle)//here 
    {

        // Convert angle (in radians) to a value between 0.0 and 1.0
        float volumeLevel = (angle + (float)Math.PI) / (2 * (float)Math.PI);
        volumeLevel = Clamp(volumeLevel, 0.0f, 1.0f); // Ensure it's between 0.0 and 1.0

        /*
        // Get current volume level
        float currentVolume;
        volume.GetMasterVolumeLevel(out currentVolume);

        // Set volume level (in dB) - Example to increase volume by 6 dB
        volume.SetMasterVolumeLevel(currentVolume * angle, IntPtr.Zero);
        */


        // Set the volume level (scale it to the range in dB)
        volume.SetMasterVolumeLevelScalar(
            volumeLevel, IntPtr.Zero);
    }
    private float Clamp(float value, float min, float max)/////here 
    {
        if (value < min) return min;
        if (value > max) return max;
        return value;
    }

    public void removeTuioObject(TuioObject o)
    {
        lock (objectList)
        {
            objectList.Remove(o.SessionID);
            System.Diagnostics.Debug.WriteLine("removed obj " + objectList.Count);
        }
        if (verbose) Console.WriteLine("del obj " + o.SymbolID + " (" + o.SessionID + ")");
        StopSound();
    }

    public void addTuioCursor(TuioCursor c)
    {
        lock (cursorList)
        {
            cursorList.Add(c.SessionID, c);
        }
        if (verbose) Console.WriteLine("add cur " + c.CursorID + " (" + c.SessionID + ") " + c.X + " " + c.Y);
    }

    public void updateTuioCursor(TuioCursor c)
    {
        if (verbose) Console.WriteLine("set cur " + c.CursorID + " (" + c.SessionID + ") " + c.X + " " + c.Y + " " + c.MotionSpeed + " " + c.MotionAccel);
    }

    public void removeTuioCursor(TuioCursor c)
    {
        lock (cursorList)
        {
            cursorList.Remove(c.SessionID);
        }
        if (verbose) Console.WriteLine("del cur " + c.CursorID + " (" + c.SessionID + ")");
    }

    public void addTuioBlob(TuioBlob b)
    {
        lock (blobList)
        {
            blobList.Add(b.SessionID, b);
        }
        if (verbose) Console.WriteLine("add blb " + b.BlobID + " (" + b.SessionID + ") " + b.X + " " + b.Y + " " + b.Angle + " " + b.Width + " " + b.Height + " " + b.Area);
    }

    public void updateTuioBlob(TuioBlob b)
    {
        if (verbose) Console.WriteLine("set blb " + b.BlobID + " (" + b.SessionID + ") " + b.X + " " + b.Y + " " + b.Angle + " " + b.Width + " " + b.Height + " " + b.Area + " " + b.MotionSpeed + " " + b.RotationSpeed + " " + b.MotionAccel + " " + b.RotationAccel);
    }

    public void removeTuioBlob(TuioBlob b)
    {
        lock (blobList)
        {
            blobList.Remove(b.SessionID);
        }
        if (verbose) Console.WriteLine("del blb " + b.BlobID + " (" + b.SessionID + ")");
    }
    private void PlaySoundForSymbol(int symbolID)
    {
        string soundPath = GetSoundPath(symbolID);
        if (string.IsNullOrEmpty(soundPath) || !File.Exists(soundPath))
        {
            Console.WriteLine($"Sound not found for symbol ID {symbolID}");

            return;
        }
        try
        {
            player = new SoundPlayer(soundPath);
            player.PlayLooping();
        }
        catch (Exception ex)
        {
            Console.WriteLine("Error playing sound: " + ex.Message);
        }

    }

    private string GetSoundPath(int symbolID)
    {
        string soundPath = null;
        switch (symbolID)
        {
            case 0:
                soundPath = "do.wav";
                SessionID = 0;
                break;
            case 1:
                soundPath = "re.wav";
                SessionID = 0;
                break;
            case 2:
                soundPath = "mi.wav";
                SessionID = 0;
                break;
            case 3:
                soundPath = "fa.wav";
                SessionID = 0;
                break;
            case 4:
                soundPath = "sol.wav";
                SessionID = 0;
                break;
            case 5:
                SessionID = 5;
                break;
            case 6:
                soundPath = "si.wav";
                break;

            default:
                soundPath = null;
                break;
        }
        return soundPath;
    }
    private void StopSound()
    {
        if (player != null)
        {
            player.Stop();
            player.Dispose();
            player = null;
        }
    }

    public void refresh(TuioTime frameTime)
    {
        Invalidate();
    }
    private void InitializeComponent()
    {
        this.SuspendLayout();
        // 
        // TuioDemo
        // 
        this.ClientSize = new System.Drawing.Size(282, 253);
        this.Name = "TuioDemo";
        this.Load += new System.EventHandler(this.TuioDemo_Load);
        this.ResumeLayout(false);

    }

    private void TuioDemo_Load(object sender, EventArgs e)
    {

    }

    public static void Main(String[] argv)
    {
        int port = 0;
        switch (argv.Length)
        {
            case 1:
                port = int.Parse(argv[0], null);
                if (port == 0) goto default;
                break;
            case 0:
                port = 3333;
                break;
            default:
                Console.WriteLine("usage: mono TuioDemo [port]");
                System.Environment.Exit(0);
                break;
        }

        TuioDemo app = new TuioDemo(port);
        Application.Run(app);
    }
    /// <summary>
    /// //////////////////////////////start from here 
    /// </summary>
    // Interfaces and classes for audio control
    [ComImport]
    [Guid("BCDE0395-E52F-467C-8E3D-C4579291692E")]
    internal class MMDeviceEnumerator { }

    internal enum EDataFlow
    {
        eRender,
        eCapture,
        eAll
    }

    internal enum ERole
    {
        eConsole,
        eMultimedia,
        eCommunications
    }

    [Guid("A95664D2-9614-4F35-A746-DE8DB63617E6"),
    InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    interface IMMDeviceEnumerator
    {
        int EnumAudioEndpoints(EDataFlow dataFlow, int dwStateMask, out object ppDevices);
        int GetDefaultAudioEndpoint(EDataFlow dataFlow, ERole role, out IMMDevice ppEndpoint);
        int GetDevice(string pwstrId, out IMMDevice ppDevice);
        int RegisterEndpointNotificationCallback(IntPtr pClient);
        int UnregisterEndpointNotificationCallback(IntPtr pClient);
    }

    [Guid("D666063F-1587-4E43-81F1-B948E807363F"),
    InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    interface IMMDevice
    {
        int Activate(ref Guid iid, int dwClsCtx, IntPtr pActivationParams, [MarshalAs(UnmanagedType.IUnknown)] out object ppInterface);
    }

    [Guid("5CDF2C82-841E-4546-9722-0CF74078229A"),
    InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    interface IAudioEndpointVolume
    {
        int RegisterControlChangeNotify(IntPtr pNotify);
        int UnregisterControlChangeNotify(IntPtr pNotify);
        int GetChannelCount(out int pnChannelCount);
        int SetMasterVolumeLevel(float fLevelDB, IntPtr pguidEventContext);
        int SetMasterVolumeLevelScalar(float fLevel, IntPtr pguidEventContext);
        int GetMasterVolumeLevel(out float pfLevelDB);
        int GetMasterVolumeLevelScalar(out float pfLevel);
        int SetChannelVolumeLevel(uint nChannel, float fLevelDB, IntPtr pguidEventContext);
        int SetChannelVolumeLevelScalar(uint nChannel, float fLevel, IntPtr pguidEventContext);
        int GetChannelVolumeLevel(uint nChannel, out float pfLevelDB);
        int GetChannelVolumeLevelScalar(uint nChannel, out float pfLevel);
        int SetMute([MarshalAs(UnmanagedType.Bool)] bool bMute, IntPtr pguidEventContext);
        int GetMute(out bool pbMute);
        int GetVolumeStepInfo(out uint pnStep, out uint pnStepCount);
        int VolumeStepUp(IntPtr pguidEventContext);
        int VolumeStepDown(IntPtr pguidEventContext);
        int QueryHardwareSupport(out uint pdwHardwareSupportMask);
        int GetVolumeRange(out float pflVolumeMindB, out float pflVolumeMaxdB, out float pflVolumeIncrementdB);
    }
}